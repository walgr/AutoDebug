plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.wpf.autodebug.demo"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.wpf.autodebug"
        minSdk = 23
        targetSdk = 33
        versionCode = 1
        versionName = "1.0.0"

        ndk {
            this.abiFilters.add("armeabi")
            this.abiFilters.add("armeabi-v7a")
            this.abiFilters.add("arm64-v8a")
        }
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("../AutoDebugRelease.jks")
            storePassword = "walgr1010"
            keyAlias = "quick"
            keyPassword = "walgr1010"
            enableV1Signing = true
            enableV2Signing = true
        }
        create("release") {
            storeFile = file("../AutoDebugRelease.jks")
            storePassword = "walgr1010"
            keyAlias = "quick"
            keyPassword = "walgr1010"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    kotlin {
        jvmToolchain(11)
    }
    lint.checkReleaseBuilds = false
    lint.abortOnError = false
}

dependencies {
   implementation(files("libs/autodebug-release.aar"))
   implementation("androidx.annotation:annotation:1.6.0")
   implementation("io.ktor:ktor-client-core:2.3.5")
   implementation("io.ktor:ktor-client-cio:2.3.5")
   implementation("io.ktor:ktor-client-logging:2.3.5")
   implementation("com.aliyun.ams:alicloud-android-hotfix:3.3.8")
    implementation("com.aliyun.ams:alicloud-android-logger:1.2.0")


//    implementation("androidx.core:core-ktx:1.10.1")
//    implementation("androidx.appcompat:appcompat:1.6.1")
//    implementation("com.google.android.material:material:1.9.0")
//
//    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.9.10")

//    implementation(project(":autodebug"))
//    implementation("com.github.walgr.Quick:Quick:0.8.5")
}